Dear learner or teacher of English, hello!

You have downloaded our bonus companion files. So here is a quick overview of the content of your bonus:

• README.txt -- this very file!


Our frequency list in ebook formats -- to read on your computer, tablet, phone, or e-reader:

• frequencylist.epub -- the list in EPUB format, supported by many readers (Apple Books, KOBO, Android apps…)
• frequencylist.azw3 -- the list in AZW3 format, for Kindle devices (Kindle for Mac, Kindle Paperwhite, etc.)


Our frequency list in spreadsheet format:

• Frequency List.numbers -- for Apple Numbers
• Frequency List.xlsx -- for Excel


And, finally, the list in PDF format:

• Frequency List (A4).pdf -- for printing in Europe and much of the world
• Frequency List (US Letter).pdf -- for printing in the US and much of the American continent


I put a lot of work into the creation of this list… Nothing like it quite existed. I hope you'll like and that it'll prove useful!

We also put a lot of effort, with my buddy Guillaume Voisin, into the creation of the website at https://frequencylist.com be sure to visit and have fun with it!



Last but not least, please share our work with your friends, colleagues and students. The more people use it, the more meaningful it makes our efforts.


Thank you for using the list, and have fun learning and teaching English!


Best regards –
Fabien Snauwaert
